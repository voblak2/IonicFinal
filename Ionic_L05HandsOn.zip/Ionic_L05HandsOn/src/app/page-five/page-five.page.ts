import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-five',
  templateUrl: './page-five.page.html',
  styleUrls: ['./page-five.page.scss'],
})
export class PageFivePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
