import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-three',
  templateUrl: './page-three.page.html',
  styleUrls: ['./page-three.page.scss'],
})
export class PageThreePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
