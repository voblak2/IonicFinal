import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-seven',
  templateUrl: './page-seven.page.html',
  styleUrls: ['./page-seven.page.scss'],
})
export class PageSevenPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
